var p1 = "https://";
var p2 = "campuslife-7e5ed";
var p3 = "-default-rtdb.firebaseio.com";
var DB_URL = p1 + p2 + p3;

var users = JSON.parse(localStorage.getItem('users')) || {};
var events = JSON.parse(localStorage.getItem('events')) || [];
var uid = localStorage.getItem('uid') || null;

var authMode = 'reg';
var editingEventId = null;
var openCards = [];
var year = 2026, month = 10, selDate = null, selCat = 'все';
var months = ["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"];

window.onload = function() {
    drawCal();
    checkAuth();
    syncFromCloud();
    setInterval(function() {
        syncFromCloud();
    }, 4000);
};

// --- ОБЛАЧНАЯ СИНХРОНИЗАЦИЯ ---
function syncFromCloud() {
    fetch(DB_URL + "/campus_data.json")
        .then(function(res) {
            if (!res.ok) throw new Error("Ошибка доступа к базе");
            return res.json();
        })
        .then(function(data) {
            if (data) {
                if (data.users) {
                    users = data.users;
                    localStorage.setItem('users', JSON.stringify(users));
                }
                if (data.events) {
                    events = Array.isArray(data.events) ? data.events : Object.values(data.events);
                    localStorage.setItem('events', JSON.stringify(events));
                } else if (data.users && !data.events) {
                    events = [];
                    localStorage.setItem('events', JSON.stringify(events));
                }
            }
            if (uid && users[uid]) {
                drawCal();
                render();
            }
        })
        .catch(function(err) {
            console.log("Синхронизация:", err.message);
        });
}

function saveToCloud() {
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('events', JSON.stringify(events));

    fetch(DB_URL + "/campus_data.json", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ users: users, events: events })
    }).catch(function(err) {
        console.log("Ошибка записи в облако:", err.message);
    });
}

// --- СЖАТИЕ ИЗОБРАЖЕНИЙ ---
function compressImage(file, callback) {
    var reader = new FileReader();
    reader.onload = function(e) {
        var img = new Image();
        img.onload = function() {
            var canvas = document.createElement('canvas');
            var maxW = 450;
            var scale = (img.width > maxW) ? (maxW / img.width) : 1;
            canvas.width = img.width * scale;
            canvas.height = img.height * scale;
            var ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            callback(canvas.toDataURL('image/jpeg', 0.6));
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

// --- СИСТЕМА АККАУНТОВ ---
function switchAuthMode(mode) {
    authMode = mode;
    var tabReg = document.getElementById('tab-reg');
    var tabLog = document.getElementById('tab-log');
    var btn = document.getElementById('auth-submit-btn');
    var passInp = document.getElementById('auth-pass');

    if (mode === 'reg') {
        tabReg.style.borderColor = '#00f2fe';
        tabReg.style.color = '#00f2fe';
        tabReg.style.fontWeight = 'bold';
        tabLog.style.borderColor = '#21262d';
        tabLog.style.color = '#8b949e';
        tabLog.style.fontWeight = 'normal';
        btn.innerText = 'Создать аккаунт';
        passInp.placeholder = 'Придумайте пароль';
    } else {
        tabLog.style.borderColor = '#00f2fe';
        tabLog.style.color = '#00f2fe';
        tabLog.style.fontWeight = 'bold';
        tabReg.style.borderColor = '#21262d';
        tabReg.style.color = '#8b949e';
        tabReg.style.fontWeight = 'normal';
        btn.innerText = 'Войти в аккаунт';
        passInp.placeholder = 'Введите ваш пароль';
    }
}

function setRoleHint() {
    var r = document.querySelector('input[name="role"]:checked').value;
    document.getElementById('auth-extra').placeholder = (r === 'teacher') ? "Предмет / Должность" : "Класс и буква (например: 9А)";
}

function handleAuthSubmit() {
    var fio = document.getElementById('auth-fio').value.trim();
    var extra = document.getElementById('auth-extra').value.trim();
    var pass = document.getElementById('auth-pass').value.trim();
    var role = document.querySelector('input[name="role"]:checked').value;

    if (!fio || !extra || !pass) {
        return alert('Заполните ФИО, класс/предмет и пароль!');
    }

    var loginKey = role + '_' + fio.toLowerCase().replace(/\s+/g, '') + '_' + extra.toLowerCase().replace(/\s+/g, '');

    if (authMode === 'reg') {
        if (users[loginKey]) {
            return alert('Такой аккаунт уже зарегистрирован! Переключитесь на вкладку «Вход».');
        }
        users[loginKey] = {
            id: loginKey,
            fio: fio,
            extra: extra.toUpperCase(),
            role: role,
            password: pass,
            ava: null,
            booked: [],
            fav: []
        };
        uid = loginKey;
        localStorage.setItem('uid', uid);
        saveToCloud();
        clearAuthFields();
        checkAuth();
    } else {
        var existingUser = users[loginKey];
        if (!existingUser) {
            fetch(DB_URL + "/campus_data.json")
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    if (data && data.users && data.users[loginKey]) {
                        users = data.users;
                        localStorage.setItem('users', JSON.stringify(users));
                        handleAuthSubmit();
                    } else {
                        alert('Аккаунт не найден! Проверьте ФИО, класс и роль.');
                    }
                })
                .catch(function() {
                    alert('Аккаунт не найден.');
                });
            return;
        }
        if (existingUser.password !== pass) {
            return alert('Неверный пароль!');
        }
        uid = loginKey;
        localStorage.setItem('uid', uid);
        clearAuthFields();
        checkAuth();
    }
}

function clearAuthFields() {
    document.getElementById('auth-fio').value = '';
    document.getElementById('auth-extra').value = '';
    document.getElementById('auth-pass').value = '';
}

function checkAuth() {
    var scr = document.getElementById('auth-screen');
    if (!uid || !users[uid]) {
        scr.style.display = 'flex';
        return;
    }
    scr.style.display = 'none';
    var u = users[uid];
    if (!u.fav) u.fav = [];
    if (!u.booked) u.booked = [];
    var isT = (u.role === 'teacher');

    document.getElementById('hdr-role').innerText = isT ? '👨‍🏫 Учитель' : '🎓 Ученик (' + u.extra + ')';
    document.getElementById('hdr-name').innerText = u.fio;
    document.getElementById('prof-name').innerText = u.fio;
    document.getElementById('prof-extra').innerText = (isT ? 'Предмет: ' : 'Класс: ') + u.extra;
    document.getElementById('btn-add').style.display = isT ? 'block' : 'none';
    document.getElementById('prof-list-title').innerText = isT ? 'Созданные мной события' : 'Мои записи';

    var img = document.getElementById('ava-img'), txt = document.getElementById('ava-txt');
    if (u.ava) { img.src = u.ava; img.style.display = 'block'; txt.style.display = 'none'; }
    else { img.style.display = 'none'; txt.style.display = 'block'; }
    render();
}

function logout() {
    uid = null;
    localStorage.removeItem('uid');
    switchAuthMode('login');
    checkAuth();
}

function uploadAva(e) {
    var file = e.target.files.item(0);
    if (!file) return;
    compressImage(file, function(compressedData) {
        users[uid].ava = compressedData;
        saveToCloud();
        checkAuth();
    });
}

// --- КАЛЕНДАРЬ ---
function moveMonth(d) {
    month += d;
    if (month > 11) { month = 0; year++; }
    if (month < 0) { month = 11; year--; }
    drawCal();
}

function drawCal() {
    var grid = document.getElementById('cal-grid');
    document.getElementById('cal-title').innerText = months[month] + ' ' + year;
    grid.innerHTML = '';

    var first = new Date(year, month, 1).getDay();
    first = (first === 0) ? 6 : first - 1;
    var days = new Date(year, month + 1, 0).getDate();

    for (var i = 0; i < first; i++) grid.innerHTML += '<div class="cal-day empty"></div>';

    for (var d = 1; d <= days; d++) {
        var dStr = year + '-' + String(month + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
        var cls = 'cal-day' + (selDate === dStr ? ' active' : '');
        if (events.some(function(e) { return e.date === dStr; })) cls += ' dot';

        var cell = document.createElement('div');
        cell.className = cls;
        cell.innerText = d;
        (function(dateVal) {
            cell.onclick = function() { selDate = dateVal; drawCal(); render(); };
        })(dStr);
        grid.appendChild(cell);
    }
}

function clearDate() { selDate = null; drawCal(); render(); }

// --- ОТРИСОВКА СПИСКОВ ---
function setCat(c, el) {
    selCat = c;
    document.querySelectorAll('.tag').forEach(function(t) { t.classList.remove('active'); });
    el.classList.add('active');
    render();
}

function getBookedCount(eventId) {
    var count = 0;
    for (var key in users) {
        if (users[key].role === 'student' && users[key].booked && users[key].booked.includes(eventId)) {
            count++;
        }
    }
    return count;
}

function render() {
    if (!uid || !users[uid]) return;
    var u = users[uid];
    if (!u.fav) u.fav = [];
    if (!u.booked) u.booked = [];
    var q = document.getElementById('inp-search').value.toLowerCase().trim();

    drawList(events, 'list-home');

    var filtered = events.filter(function(e) {
        return e.title.toLowerCase().indexOf(q) !== -1 &&
               (selCat === 'все' || e.cat === selCat) &&
(!selDate || e.date === selDate);
});
document.getElementById('search-title').innerText = selDate ? 'События на ' + selDate.split('-').reverse().join('.') : 'Все события';
drawList(filtered, 'list-search');
var profList = (u.role === 'teacher')
? events.filter(function(e) { return e.author === uid; })
: events.filter(function(e) { return u.booked.includes(e.id); });
drawList(profList, 'list-profile');
drawList(events.filter(function(e) { return u.fav.includes(e.id); }), 'list-fav');
}
function isEventPast(ev) {
    var evTime = new Date(ev.date + 'T' + ev.time);
    return !isNaN(evTime.getTime()) && (evTime < new Date());
}
function drawList(arr, boxId) {
    var box = document.getElementById(boxId);
    box.innerHTML = '';
    if (!arr.length) {
        box.innerHTML = '<p class="muted" style="text-align:center; padding:15px;">Список пуст</p>';
        return;
    }

    var u = users[uid];
    var isTeacher = (u.role === 'teacher');

    arr.forEach(function(ev) {
        var isB = u.booked.includes(ev.id);
        var isF = u.fav.includes(ev.id);
        var count = getBookedCount(ev.id);
        var views = ev.views || 0;
        var past = isEventPast(ev);

        var card = document.createElement('div');
        card.className = 'card';
        card.setAttribute('data-id', ev.id);
        if (openCards.includes(ev.id)) card.classList.add('open');

        if (ev.photo) {
            var img = document.createElement('img');
            img.src = ev.photo;
            card.appendChild(img);
        }

        var badge = document.createElement('span');
        badge.className = past ? 'status-badge status-done' : 'status-badge status-upcoming';
        badge.textContent = past ? '✅ Состоялось' : '⏳ Предстоит';
        card.appendChild(badge);

        var head = document.createElement('div');
        head.style.cssText = 'display:flex; justify-content:space-between; align-items:center;';
        head.innerHTML = '<h3>' + ev.title + '</h3><small class="muted">▼</small>';
        card.appendChild(head);

        var details = document.createElement('div');
        details.className = 'card-details';
        var descText = ev.desc ? '<p class="ev-desc">' + ev.desc + '</p>' : '';
        details.innerHTML =
            '<p class="muted">📅 ' + ev.date.split('-').reverse().join('.') + ' | 🕒 ' + ev.time + '</p>' +
            '<p class="muted">📍 ' + ev.loc + ' | 🏷️ ' + ev.cat + '</p>' +
            descText +
            '<p style="color:var(--accent); font-size:13px; margin-top:4px; font-weight:bold;">👥 Записалось: ' + count + ' чел. | 👁 Просмотров: ' + views + '</p>';
                if (past) {
                    var rate = getRatingInfo(ev);
                    var rateBox = document.createElement('div');
                    rateBox.className = 'rate-box';

                    var rateTitle = document.createElement('div');
                    rateTitle.style.cssText = 'font-size:13px; font-weight:bold;';
                    rateTitle.textContent = rate.count ? ('Рейтинг: ⭐ ' + rate.avg + ' (' + rate.count + ' оц.)') : 'Рейтинг: ⭐ Пока нет оценок';
                    rateBox.appendChild(rateTitle);

                    if (!isTeacher) {
                        var starsRow = document.createElement('div');
                        starsRow.style.cssText = 'margin-top:4px; display:flex; align-items:center; gap:2px;';
                        var lbl = document.createElement('span');
                        lbl.className = 'muted';
                        lbl.textContent = 'Оценить: ';
                        starsRow.appendChild(lbl);

                        var myRate = (ev.ratings && ev.ratings[uid]) || 0;
                        for (var s = 1; s <= 5; s++) {
                            (function(starScore) {
                                var sBtn = document.createElement('button');
                                sBtn.className = 'star-btn';
                                sBtn.textContent = (starScore <= myRate) ? '⭐' : '☆';
                                sBtn.onclick = function(e) {
                                    e.stopPropagation();
                                    rateEv(ev.id, starScore);
                                };
                                starsRow.appendChild(sBtn);
                            })(s);
                        }
                        rateBox.appendChild(starsRow);
                    }
                    details.appendChild(rateBox);
                }

        card.appendChild(details);

        var act = document.createElement('div');
        act.className = 'card-act';
        act.onclick = function(e) { e.stopPropagation(); };

        if (!isTeacher) {
            var bBtn = document.createElement('button');
            bBtn.className = isB ? 'btn booked' : 'btn';
            bBtn.textContent = isB ? 'Вы записаны' : 'Записаться';
            bBtn.onclick = function() { togBook(ev.id); };
            act.appendChild(bBtn);
        } else {
            var authLbl = document.createElement('small');
            authLbl.className = 'muted';
            authLbl.textContent = 'Автор: ' + ev.authorName;
            act.appendChild(authLbl);
        }

        var rightBox = document.createElement('div');
        rightBox.style.cssText = 'display:flex; gap:6px; align-items:center;';

        if (isTeacher) {
                    var listBtn = document.createElement('button');
                    listBtn.className = 'btn-sub';
                    listBtn.style.cssText = 'width:auto; padding:6px 10px; font-size:12px;';
                    listBtn.textContent = '📋';
                    listBtn.onclick = function() { showParticipants(ev.id); };
                    rightBox.appendChild(listBtn);

            var editBtn = document.createElement('button');
            editBtn.className = 'btn-sub';
            editBtn.style.cssText = 'width:auto; padding:6px 10px; font-size:12px;';
            editBtn.textContent = '✏️ Изм.';
            editBtn.onclick = function() { openEditModal(ev.id); };
            rightBox.appendChild(editBtn);

            var delBtn = document.createElement('button');
            delBtn.className = 'btn-del';
            delBtn.textContent = '🗑';
            delBtn.onclick = function() { delEv(ev.id); };
            rightBox.appendChild(delBtn);
        }

        var likeBtn = document.createElement('button');
        likeBtn.style.cssText = 'background:none; border:none; font-size:20px; cursor:pointer; padding:2px 4px;';
        likeBtn.textContent = isF ? '❤️' : '🤍';
        likeBtn.onclick = function() { togFav(ev.id); };
        rightBox.appendChild(likeBtn);

        act.appendChild(rightBox);
        card.appendChild(act);
        box.appendChild(card);
    });
}

// --- ДЕЙСТВИЯ ---
function togBook(id) {
if (!users[uid].booked) users[uid].booked = [];
var b = users[uid].booked;
users[uid].booked = b.includes(id) ? b.filter(function(x) { return x !== id; }) : b.concat(id);
saveToCloud();
render();
}
function togFav(id) {
if (!users[uid].fav) users[uid].fav = [];
var f = users[uid].fav;
users[uid].fav = f.includes(id) ? f.filter(function(x) { return x !== id; }) : f.concat(id);
saveToCloud();
render();
}
function delEv(id) {
if (!confirm('Удалить событие?')) return;
events = events.filter(function(e) { return e.id !== id; });
saveToCloud();
drawCal(); render();
}
// --- СОЗДАНИЕ И РЕДАКТИРОВАНИЕ СОБЫТИЙ ---
function toggleModal(show) { document.getElementById('modal-add').style.display = show ? 'flex' : 'none'; }
function openAddModal() {
editingEventId = null;
document.getElementById('modal-ev-title').innerText = 'Новое событие';
document.getElementById('modal-ev-btn').innerText = 'Создать';
document.getElementById('ev-photo-lbl').innerText = 'Фото события:';
document.getElementById('ev-title').value = '';
document.getElementById('ev-date').value = '';
document.getElementById('ev-time').value = '';
document.getElementById('ev-loc').value = '';
document.getElementById('ev-cat').value = 'Спорт';
document.getElementById('ev-photo').value = '';
var descEl = document.getElementById('ev-desc');
if (descEl) descEl.value = '';
toggleModal(true);
}
function openEditModal(id) {
var ev = events.find(function(e) { return e.id === id; });
if (!ev) return;
editingEventId = id;
document.getElementById('modal-ev-title').innerText = 'Редактировать событие';
document.getElementById('modal-ev-btn').innerText = 'Сохранить изменения';
document.getElementById('ev-photo-lbl').innerText = 'Новое фото (необязательно):';
document.getElementById('ev-title').value = ev.title;
document.getElementById('ev-date').value = ev.date;
document.getElementById('ev-time').value = ev.time;
document.getElementById('ev-loc').value = ev.loc;
document.getElementById('ev-cat').value = ev.cat;
document.getElementById('ev-photo').value = '';
var descEl = document.getElementById('ev-desc');
if (descEl) descEl.value = ev.desc || '';

toggleModal(true);
}
function saveEvent() {
var t = document.getElementById('ev-title').value.trim();
var d = document.getElementById('ev-date').value;
var tm = document.getElementById('ev-time').value;
var l = document.getElementById('ev-loc').value.trim();
var c = document.getElementById('ev-cat').value;
var descEl = document.getElementById('ev-desc');
var descVal = descEl ? descEl.value.trim() : '';
var file = document.getElementById('ev-photo').files.item(0);
if (!t || !d || !tm || !l) return alert('Заполните все поля!');
var finishSave = function(newPhotoData) {

if (editingEventId) {
var idx = events.findIndex(function(e) { return e.id === editingEventId; });
if (idx !== -1) {
events[idx].title = t;
events[idx].date = d;
events[idx].time = tm;
events[idx].loc = l;
events[idx].cat = c;
events[idx].desc = descVal;
if (newPhotoData) {
events[idx].photo = newPhotoData;
}
}
} else {
events.unshift({
id: 'e' + Date.now(),
title: t,
date: d,
time: tm,
loc: l,
cat: c,
desc: descVal,
photo: newPhotoData,
author: uid,
authorName: users[uid].fio
});
}
saveToCloud();
toggleModal(false);
drawCal();
render();
};
if (file) {
compressImage(file, finishSave);
} else {
finishSave(null);
}
}
function go(scrId, btn) {
document.querySelectorAll('.screen').forEach(function(s) { s.classList.remove('active'); });
document.querySelectorAll('.nav-btn').forEach(function(b) { b.classList.remove('active'); });
document.getElementById(scrId).classList.add('active');
if (btn) btn.classList.add('active');
}
var isLight = false;
function toggleTheme() {
    document.body.classList.toggle("light-theme");
    var isLight = document.body.classList.contains("light-theme");

    var btn = document.getElementById("theme-btn");
    if (btn) {
        btn.innerHTML = isLight ? "☾" : "☀";
    }
}

document.addEventListener("click", function(e) {
    var card = e.target.closest(".card");
    if (card && !e.target.closest("button")) {
        var evId = card.getAttribute("data-id");
        card.classList.toggle("open");
        if (card.classList.contains("open")) {
            if (!openCards.includes(evId)) openCards.push(evId);
            var ev = events.find(function(item) { return item.id === evId; });
            if (ev) {
                ev.views = (ev.views || 0) + 1;
                saveToCloud();
                render();
            }
        } else {
            openCards = openCards.filter(function(id) { return id !== evId; });
        }
    }
});

function showParticipants(evId) {
    var box = document.getElementById('users-list-box');
    box.innerHTML = '';
    var list = [];
    for (var key in users) {
        if (users[key].role === 'student' && users[key].booked && users[key].booked.includes(evId)) {
            list.push(users[key]);
        }
    }
    if (!list.length) {
        box.innerHTML = '<p class="muted" style="text-align:center; padding:10px;">Пока никто не записался</p>';
    } else {
        list.forEach(function(st, i) {
            var row = document.createElement('div');
            row.className = 'user-row';
            row.innerHTML = '<span>' + (i + 1) + '. ' + st.fio + '</span><b>' + st.extra + '</b>';
            box.appendChild(row);
        });
    }
    document.getElementById('modal-users').style.display = 'flex';
}

function getRatingInfo(ev) {
    if (!ev.ratings) return { avg: 0, count: 0 };
    var vals = Object.values(ev.ratings);
    if (!vals.length) return { avg: 0, count: 0 };
    var sum = vals.reduce(function(a, b) { return a + b; }, 0);
    return { avg: (sum / vals.length).toFixed(1), count: vals.length };
}

function rateEv(evId, score) {
    var ev = events.find(function(e) { return e.id === evId; });
    if (!ev) return;
    if (!ev.ratings) ev.ratings = {};
    ev.ratings[uid] = score;
    saveToCloud();
    render();
}
